<?php



namespace Vdcstore\DualPrices\Plugin\Directory\Model;

use Magento\Directory\Model\PriceCurrency as PriceCurrencyModel;
use Vdcstore\DualPrices\Helper\Conversion;
use Vdcstore\DualPrices\Helper\Currency;

class PriceCurrency
{

    
    protected $helper;
    protected $currencyyy;

   
    public function __construct(
        Conversion $helper,
        Currency $currencyyy
    ) {
        $this->helper = $helper;
        $this->currencyyy = $currencyyy;
    }

 
    public function afterFormat(
        PriceCurrencyModel $subject,
        string $result,
        $amount
    ): string {
        
        return $result .$this->helper->formatSidePrice((float)$amount);

    }
}
