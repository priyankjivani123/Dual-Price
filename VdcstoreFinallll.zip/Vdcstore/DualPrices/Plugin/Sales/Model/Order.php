<?php

declare(strict_types=1);

namespace Vdcstore\DualPrices\Plugin\Sales\Model;

use Magento\Sales\Model\Order as OrderModel;
use Vdcstore\DualPrices\Helper\Conversion;
use Magento\Framework\App\State;
use Magento\Framework\App\Area;

class Order
{

    protected $helper;

    protected $appState;

    
    public function __construct(
        Conversion $helper,
        State $appState
    ) {
        $this->helper = $helper;
        $this->appState = $appState;
    }

    
    public function afterFormatPrice(
        OrderModel $subject,
        string $result,
        $price
    ): string {
        if ($this->appState->getAreaCode() !== Area::AREA_FRONTEND) {
            return $result;
        }

        return $result . $this->helper->formatSidePrice((float)$price);
    }
}
