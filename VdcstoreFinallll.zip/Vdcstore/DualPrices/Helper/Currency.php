<?php

namespace Vdcstore\DualPrices\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;
use Vdcstore\DualPrices\Block\Currencyrate;

class Currency extends AbstractHelper
{

    protected $Currencyrate;

    protected $_storeManager;

    protected $registry;

    protected $currencyFactory;

    private $layerResolver;

    protected $_product;


    protected $categoryFactory;


    public function __construct(
        Currencyrate                                $Currencyrate,
        \Magento\Framework\Locale\CurrencyInterface $localeCurrency,
        \Magento\Store\Model\StoreManagerInterface  $storeManager,
        \Magento\Directory\Model\currencyFactory    $currencyFactory,
        \Magento\Catalog\Model\Layer\Resolver       $layerResolver,
        \Magento\Catalog\Model\CategoryFactory      $categoryFactory,
        \Magento\Catalog\Model\ProductFactory       $productFactory,
        \Magento\Framework\Registry                 $registry


    )
    {
        $this->registry = $registry;
        $this->Currencyrate = $Currencyrate;
        $this->_storeManager = $storeManager;
        $this->localeCurrency = $localeCurrency;
        $this->currencyFactory = $currencyFactory;
        $this->categoryFactory = $categoryFactory;
        $this->productFactory = $productFactory;
        $this->layerResolver = $layerResolver;
    }


    public function getCurrentCurrencyCode()
    {
        return $this->_storeManager->getStore()->getCurrentCurrencyCode();

    }

    public function getCurrenctCurrencyPrice($CurrencyCode)
    {
        return $this->_storeManager->getStore()->getBaseCurrency()->getRate($CurrencyCode);
    }

    public function getSymbol()
    {

        $getAvailableCurrencyCodes = $this->Currencyrate->getAvailableCurrencyCodes();
        $getCurrentCurrencyCode = $this->_storeManager->getStore()->getCurrentCurrencyCode();
        $BaseCurrencyCode = end($getAvailableCurrencyCodes);
        $getBaseCurrencyRate = $this->_storeManager->getStore()->getBaseCurrency()->getRate($BaseCurrencyCode);
        $getCurrentCurrencyRate = $this->Currencyrate->getCurrentCurrencyRate();

        $arraySearc = array_search($getCurrentCurrencyCode, $getAvailableCurrencyCodes);
        foreach (array_keys($getAvailableCurrencyCodes, $getCurrentCurrencyCode) as $key) {
            array_splice($getAvailableCurrencyCodes, $arraySearc, 1);
        }
        $CountCurrencyCode = count($getAvailableCurrencyCodes);

        $getBaseCurrencyCodeArray = [];
        for ($i = 0; $i < $CountCurrencyCode; $i++) {

            $checkIfNull = $this->localeCurrency->getCurrency($getAvailableCurrencyCodes[$i])->getSymbol();
            if ($checkIfNull == '') {
                $getBaseCurrencyCodeArray[] = $getAvailableCurrencyCodes[$i];

            } else {
                $getBaseCurrencyCodeArray[] = $this->localeCurrency->getCurrency($getAvailableCurrencyCodes[$i])->getSymbol();
            }
        }
        return $getBaseCurrencyCodeArray;
    }

    public function getCurrencyy()
    {
        $getAvailableCurrencyCodes = $this->Currencyrate->getAvailableCurrencyCodes();
        $getCurrentCurrencyCode = $this->_storeManager->getStore()->getCurrentCurrencyCode();
        $BaseCurrencyCode = end($getAvailableCurrencyCodes);
        $getBaseCurrencyRate = $this->_storeManager->getStore()->getBaseCurrency()->getRate($BaseCurrencyCode);
        $getCurrentCurrencyRate = $this->Currencyrate->getCurrentCurrencyRate();

        $arraySearc = array_search($getCurrentCurrencyCode, $getAvailableCurrencyCodes);
        foreach (array_keys($getAvailableCurrencyCodes, $getCurrentCurrencyCode) as $key) {
            array_splice($getAvailableCurrencyCodes, $arraySearc, 1);
        }
        $CountCurrencyCode = count($getAvailableCurrencyCodes);
        $getBaseCurrencyCodeArray = [];
        for ($i = 0; $i < $CountCurrencyCode; $i++) {
            $getBaseCurrencyCodeArray[] = $this->localeCurrency->getCurrency($getAvailableCurrencyCodes[$i])->getSymbol();
        }
        $getAvailableCurrencyCodesCount = count($getAvailableCurrencyCodes);
        $array = [];

        for ($i = 0; $i < $getAvailableCurrencyCodesCount; $i++) {
            $array[] = $this->_storeManager->getStore()->getBaseCurrency()->getRate($getAvailableCurrencyCodes[$i]);
        }
        return $array;
    }

    public function getCurrenctProductPrice()
    {
        $product = $this->registry->registry('current_product');
        $getProductPriceInBaseCurrency = $product->getPrice();

        return $getProductPriceInBaseCurrency;
    }

}
