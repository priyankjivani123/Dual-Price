<?php

declare(strict_types=1);

namespace Vdcstore\DualPrices\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Vdcstore\DualPrices\Helper\Currency;


class Conversion
{
    protected $request;

    const XML_PATH_CATALOG_DUAL_PRICES_SEPARATOR = 'currency/dual_prices/separator';
    const XML_PATH_MODULE_RECIPIENT = 'currency/dual_prices/enable';


    protected $scopeConfig;

    protected $currency;


    public function __construct(
        ScopeConfigInterface                    $scopeConfig,
        Currency                                $currency,
        \Magento\Framework\App\RequestInterface $request
    )
    {
        $this->scopeConfig = $scopeConfig;
        $this->request = $request;
        $this->currency = $currency;

    }

    public function getMultiValue($amount)
    {
        $getCurrentCurrencyCode = $this->currency->getCurrentCurrencyCode();
        $getCurrenctCurrencyPrice = $this->currency->getCurrenctCurrencyPrice($getCurrentCurrencyCode);
        if ($getCurrenctCurrencyPrice == '') {
            $getCurrenctCurrencyPrice = 1;

        } else {
            $getCurrenctCurrencyPrice = $getCurrenctCurrencyPrice;

        }
        $getCurrencyValue = $this->currency->getCurrencyy();
        $getSymbol = $this->currency->getSymbol();
        $getSymbolCount = count($getSymbol);
        $sideCurrencyInfo = $this->getSideCurrencyInfo();
        $ConvertedPriceee = array();
        for ($i = 0; $i < $getSymbolCount; $i++) {
            $ConvertedPriceee[] = $getSymbol[$i] . " " . round($amount * $getCurrencyValue[$i], 2) / $getCurrenctCurrencyPrice;
        }
        $separator = $sideCurrencyInfo['separator'];
        $impload = implode($separator, $ConvertedPriceee);

        if (!$impload == '') {
            return $impload;

        } else {

            return '';
        }
    }

    public function formatSidePrice(float $amount): string
    {
        $status = $this->getModuleStatus();
        if ($status == '1') {
            $getMultiValue = $this->getMultiValue($amount);

            $sideCurrencyInfo = $this->getSideCurrencyInfo();
            if ($getMultiValue == '') {

                return '';
            } else {

                return sprintf(
                    '<span class="side-price">%s%s%s</span>',
                    $sideCurrencyInfo['separator'] ?
                        "<span class=\"side-price-separator\">{$sideCurrencyInfo['separator']}</span>" :
                        ' ', $this->getMultiValue($amount), $sideCurrencyInfo['symbol']
                );
            }
        } else {

            return '';
        }
    }

    public function getSideCurrencyInfo(): array
    {
        $status = $this->getModuleStatus();
        $getCurrentCurrencyCode = $this->currency->getCurrentCurrencyCode();
        $getCurrenctCurrencyPrice = $this->currency->getCurrenctCurrencyPrice($getCurrentCurrencyCode);
        if ($getCurrenctCurrencyPrice == '') {
            $getCurrenctCurrencyPrice = 1;

        } else {
            $getCurrenctCurrencyPrice = $getCurrenctCurrencyPrice;

        }
        $getCurrencyValue = $this->currency->getCurrencyy();
        $getSymbol = $this->currency->getSymbol();

        return [
            'rate' => $getCurrencyValue,
            'demo' => 'demo',
            'currentcurrencyprice' => $getCurrenctCurrencyPrice,
            'symboll' => $getSymbol,
            'symbol' => "",
            'status' => $status,
            'separator' => trim((string)$this->scopeConfig->getValue(self::XML_PATH_CATALOG_DUAL_PRICES_SEPARATOR))
        ];
    }

    public function getModuleStatus()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

        return $this->scopeConfig->getValue(self::XML_PATH_MODULE_RECIPIENT, $storeScope);
    }
}
