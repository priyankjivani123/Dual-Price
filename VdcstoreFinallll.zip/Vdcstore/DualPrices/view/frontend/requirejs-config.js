var config = {
    map: {
        '*': {
            'Magento_Tax/template/checkout/cart/totals/grand-total':
                'Vdcstore_DualPrices/template/checkout/cart/totals/grand-total',
            'Magento_Tax/template/checkout/summary/grand-total':
                'Vdcstore_DualPrices/template/checkout/summary/grand-total',
            'Magento_Tax/template/checkout/summary/subtotal':
                'Vdcstore_DualPrices/template/checkout/summary/subtotal',
            'Magento_Tax/template/checkout/cart/totals/tax':
                'Vdcstore_DualPrices/template/checkout/cart/totals/tax',
            'Magento_Tax/template/checkout/shipping_method/price':
                'Vdcstore_DualPrices/template/checkout/shipping_method/price',
            'Magento_Weee/template/checkout/summary/item/price':
                'Vdcstore_DualPrices/template/checkout/summary/item/price',
            'Magento_Tax/template/checkout/cart/totals/shipping':
                'Vdcstore_DualPrices/template/checkout/cart/totals/shipping',
            'Magento_Tax/template/checkout/summary/shipping':
                'Vdcstore_DualPrices/template/checkout/summary/shipping',
            'Magento_SalesRule/template/summary/discount':
                'Vdcstore_DualPrices/template/summary/discount',
            'Magento_SalesRule/template/cart/totals/discount':
                'Vdcstore_DualPrices/template/cart/totals/discount',
            'Magento_Tax/template/checkout/minicart/subtotal/totals':
                'Vdcstore_DualPrices/template/checkout/minicart/subtotal/totals',
            'Magento_Checkout/template/estimation':
                'Vdcstore_DualPrices/template/checkout/estimation',
            'Magento_Tax/template/checkout/summary/tax':
                'Vdcstore_DualPrices/template/checkout/summary/tax'
        }
    },
    config: {
        mixins: {
            'Magento_Catalog/js/price-utils': {
                'Vdcstore_DualPrices/js/price-utils-mixin': true
            },
            'Magento_Catalog/js/price-box': {
                'Vdcstore_DualPrices/js/price-box-mixin': true
            },
            'Magento_Catalog/js/price-options': {
                'Vdcstore_DualPrices/js/price-options-mixin': true
            },
            'Magento_ConfigurableProduct/js/configurable': {
                'Vdcstore_DualPrices/js/configurable-mixin': true
            },
            'Magento_Bundle/js/price-bundle': {
                'Vdcstore_DualPrices/js/price-bundle-mixin': true
            }
        }
    }
};
