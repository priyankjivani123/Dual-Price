define([
    'jquery',
    'mage/utils/wrapper'
], function ($, wrapper) {
    'use strict';

    return function (priceUtils) {
        priceUtils.formatPrice = wrapper.wrapSuper(priceUtils.formatPrice, function (amount, format, isShowSign) {
            var price = this._super(amount, format, isShowSign);

            var origPattern = format.pattern;
            var currentcurrencyprice =window.conversion.currentcurrencyprice;
            var secondPricew=[];
                for(var i =0; i< window.conversion.rate.length; i++)
                {
                    var secondPrice = this._super(  
                        (amount * parseFloat(window.conversion.rate[i])).toFixed(2)/currentcurrencyprice,
                        {pattern: '%s'+window.conversion.symboll[i]},
                        isShowSign,
                    
                );
                     secondPricew.push(secondPrice);

                }
          var allcourancyprice=secondPricew.join(window.conversion.separator);

          console.log(window.conversion);

            this._super(1, {pattern: origPattern}, isShowSign);

            var separator = allcourancyprice ?
                '<span class="side-price-separator">' + window.conversion.separator + '</span>' :
                ' ';
                var DisplayPrice= '<span class="side-price">' + separator + allcourancyprice + '</span>';

                var status=window.conversion.status;
                if(status=='1')
                {
                    return price +DisplayPrice;
                }else
                {

                    return price;
                 }
       
       });

        return priceUtils;
    };
});
