define([
    'jquery',
    'Magento_Catalog/js/price-utils',
], function ($, utils) {
    'use strict';

    var mixin = {
        reloadPrice: function reDrawPrices()
        {
            var priceFormat = (this.options.priceConfig && this.options.priceConfig.priceFormat) || {};

            _.each(this.cache.displayPrices, function (price, priceCode) {
                price.final = _.reduce(price.adjustments, function (memo, amount) {
                    return memo + amount;
                }, price.amount);

                price.formatted = utils.formatPrice(price.final, priceFormat);

                $('[data-price-type="' + priceCode + '"]', this.element).html(
                    '<span class="price">' +
                    price.formatted +
                    '</span>'
                );
            }, this);
        }
    };

    return function (priceBoxWidget) {
        $.widget('mage.priceBox', priceBoxWidget, mixin);

        return $.mage.priceBox;
    };
});