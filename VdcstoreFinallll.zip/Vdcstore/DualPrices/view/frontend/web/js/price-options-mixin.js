define([
    'jquery',
    'mage/template',
    'priceUtils'
], function ($, mageTemplate, utils) {
    'use strict';

    var mixin = {
        _applyOptionNodeFix: function applyOptionNodeFix(options)
        {
            var config = this.options,
                format = config.priceFormat,
                template = config.optionTemplate;

            template = mageTemplate(template);
            options.filter('select').each(function (index, element) {
                var $element = $(element),
                    optionId = utils.findOptionId($element),
                    optionConfig = config.optionConfig && config.optionConfig[optionId];

                $element.find('option').each(function (idx, option) {
                    var $option,
                        optionValue,
                        toTemplate,
                        prices;

                    $option = $(option);
                    optionValue = $option.val();

                    if (!optionValue && optionValue !== 0) {
                        return;
                    }

                    toTemplate = {
                        data: {
                            label: optionConfig[optionValue] && optionConfig[optionValue].name
                        }
                    };
                    prices = optionConfig[optionValue] ? optionConfig[optionValue].prices : null;

                    if (prices) {
                        _.each(prices, function (price, type) {
                            var value = +price.amount;

                            value += _.reduce(price.adjustments, function (sum, x) {
                                return sum + x;
                            }, 0);
                            toTemplate.data[type] = {
                                value: value,
                                formatted: utils.formatPrice(value, format).replace(/(<([^>]+)>)/gi, "") // remove html tags added via price-utils-mixin.js
                            };
                        });

                        $option.text(template(toTemplate));
                    }
                });
            });
        }
    };

    return function (priceOptionsWidget) {
        $.widget('mage.priceOptions', priceOptionsWidget, mixin);

        return $.mage.priceOptions;
    };
});