<?php

declare(strict_types=1);

namespace Vdcstore\DualPrices\ViewModel;

use Vdcstore\DualPrices\Helper\Conversion;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\View\Element\Block\ArgumentInterface;

class ConversionData implements ArgumentInterface
{
    /**
     * @var Conversion
     */
    protected $helper;

    /**
     * @var SerializerInterface
     */
    protected $serializer;

    /**
     * ConversionData constructor.
     * @param Conversion $helper
     * @param SerializerInterface $serializer
     */
    public function __construct(
        Conversion $helper,
        SerializerInterface $serializer
    ) {
        $this->helper = $helper;
        $this->serializer = $serializer;
    }

    /**
     * @return bool|string
     */
    public function getSerializedData()
    {
        $sideCurrencyInfo = $this->helper->getSideCurrencyInfo();

        return $this->serializer->serialize(
            [
                'rate' => $sideCurrencyInfo['rate'],
                'currentcurrencyprice' => $sideCurrencyInfo['currentcurrencyprice'],
                'symbol' => $sideCurrencyInfo['symbol'],
                'status' => $sideCurrencyInfo['status'],
                'symboll' => $sideCurrencyInfo['symboll'],
                'separator' => $sideCurrencyInfo['separator']
            ]
        );
    }
}
