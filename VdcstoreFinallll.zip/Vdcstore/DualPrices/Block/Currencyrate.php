<?php
namespace Vdcstore\DualPrices\Block;

class Currencyrate extends \Magento\Framework\View\Element\Template
{
    protected $_storeManager;
    protected $_currency;
    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,        
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Directory\Model\Currency $currency,        
        array $data = []
    )
    {        
        $this->_storeManager = $storeManager;
        $this->_currency = $currency;        
        parent::__construct($context, $data);
    }
    
    
    public function getBaseCurrencyCode()
    {
        return $this->_storeManager->getStore()->getBaseCurrencyCode();
    }
    
    
    public function getCurrentCurrencyCode()
    {
        return $this->_storeManager->getStore()->getCurrentCurrencyCode();
    }    
 
    public function getDefaultCurrencyCode()
    {
        return $this->_storeManager->getStore()->getDefaultCurrencyCode();
    }
    
    
    public function getAvailableCurrencyCodes($skipBaseNotAllowed = false)
    {
        return $this->_storeManager->getStore()->getAvailableCurrencyCodes($skipBaseNotAllowed);
    }
    
   
    public function getAllowedCurrencies()
    {
        return $this->_storeManager->getStore()->getAllowedCurrencies();
    }
    
   
    public function getCurrentCurrencyRate()
    {
        return $this->_storeManager->getStore()->getCurrentCurrencyRate();
    }
    
      
    public function getCurrentCurrencySymbol()
    {
        return $this->_currency->getCurrencySymbol();
    }    
}
?>