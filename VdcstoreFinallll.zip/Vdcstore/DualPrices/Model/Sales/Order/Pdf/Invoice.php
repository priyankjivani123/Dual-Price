<?php

declare(strict_types=1);

namespace Vdcstore\DualPrices\Model\Sales\Order\Pdf;

use Magento\Sales\Model\Order\Pdf\Invoice as Original;
use Magento\Sales\Model\AbstractModel;

class Invoice extends Original
{

  
    protected function insertTotals($page, $source) //phpcs:ignore
    {
        $order = $source->getOrder();
        $totals = $this->_getTotalsList();
        $lineBlock = ['lines' => [], 'height' => 15];
        foreach ($totals as $total) {
            $total->setOrder($order)->setSource($source);

            if ($total->canDisplay()) {
                $total->setFontSize(10);
                foreach ($total->getTotalsForDisplay() as $totalData) {
                    $euroAmount = sprintf(' / %0.2f€', round((float)$total->getAmount() / 7.5345, 2));

                    $lineBlock['lines'][] = [
                        [
                            'text' => $totalData['label'],
                            'feed' => 475,
                            'align' => 'right',
                            'font_size' => $totalData['font_size'],
                            'font' => 'bold',
                        ],
                        [
                            'text' => $totalData['amount'],
                            'feed' => 565 - $this->widthForStringUsingFontSize(
                                $euroAmount,
                                \Zend_Pdf_Font::fontWithPath(
                                    $this->_rootDirectory->getAbsolutePath('lib/internal/GnuFreeFont/FreeSerif.ttf')
                                ),
                                9
                            ),
                            'align' => 'right',
                            'font_size' => $totalData['font_size'],
                            'font' => 'bold'
                        ],
                        [
                            'text' => $euroAmount,
                            'feed' => 565,
                            'align' => 'right',
                            'font_size' => 9,
                        ]
                    ];
                }
            }
        }

        $this->y -= 20;
        $page = $this->drawLineBlocks($page, [$lineBlock]);
        return $page;
    }
}
